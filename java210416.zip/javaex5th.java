import java.util.Scanner;

public class javaex5th {
    public static void main(String[] args){
        //Q4-18
        // Scanner sc=new Scanner(System.in);
        // System.out.print("Number? ");
        // int num=sc.nextInt();
        // int count=0;

        // for (int i=1;i<=num;i++){
        //     if(num%i==0){
        //         System.out.print(i+" ");
        //         count++;
        //     }
        // }
        // System.out.println("\nnumbers is "+count );

        //Q4-19
        // Scanner sc=new Scanner(System.in);
        // System.out.print("Number? ");
        // int num=sc.nextInt();

        // for (int i=1;i<=num;i++){
        //     System.out.println(i+"'s power is "+(i*i));
        // }

        //Q4-20
        // Scanner sc=new Scanner(System.in);
        // int num;
        // int retry=0;
        // do{
        //     do{
        //         System.out.print("Number? ");
        //         num=sc.nextInt();
        //     }while(num>12 || num<0);

        //     switch(num){
        //         case 12:
        //         case 1:
        //         case 2:
        //         System.out.println("Winter");
        //         break;
        //         case 3:
        //         case 4:
        //         case 5:
        //         System.out.println("Spring");
        //         break;
        //         case 6:
        //         case 7:
        //         case 8:
        //         System.out.println("Summer");
        //         break;
        //         case 9:
        //         case 10:
        //         case 11:
        //         System.out.println("Autumn");
        //         break;
        //     }
        // System.out.print("Againg? 1.Yes/0.No :");
        // retry=sc.nextInt();
        // }while(retry!=0);

        //Q4-21
        Scanner sc=new Scanner(System.in);
        System.out.print("Number? ");
        int num=sc.nextInt();

        for(int i=1;i<=num;i++){
            for(int j=1;j<=num;j++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
