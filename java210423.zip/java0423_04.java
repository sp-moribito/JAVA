import java.util.Arrays;
import java.util.Scanner;

public class java0423_04 {
    public static void main(String[] args){

        Scanner sc=new Scanner(System.in);

         //5-9, 5-10 skip
         //6-1

        //  double[] arr={1,2,3,4,5};

        //  for (int i=0;i<arr.length;i++){
        //      System.out.println(arr[i]);
        //  }

         //6-2
        //  int[] a=new int[5];

        //  for (int i=0;i<a.length;i++){
        //      a[i]=5-i;
        //      System.out.println("a["+i+"] = "+a[i]);
        //  }

         //6-6
        //  System.out.print("Array's length? > ");
        //  int[] a=new int[sc.nextInt()];

        //  for (int i=0;i<a.length;i++){
        //      System.out.print("a["+i+"] = ");
        //      a[i]=sc.nextInt();
        //  }
        //  System.out.print("a={");
        //  for (int i=0;i<a.length;i++){
        //     if(i!=a.length-1)
        //         System.out.print(a[i]+", ");
        //     else
        //         System.out.print(a[i]);
        //  }
        //  System.out.print("}\n");

         //6-7
         System.out.print("Member's number? > ");
         int[] a=new int[sc.nextInt()];
         int sum=0;
         int max=0;
         int min=100;

         System.out.println("Input member's score.");

         for (int i=0;i<a.length;i++){
             System.out.print("Member No."+(i+1)+"'s score is ");
             a[i]=sc.nextInt();
             sum=sum+a[i];
             if (max<a[i]) max=a[i];
             if (min>a[i]) min=a[i];
         }
         System.out.println("Sum is "+sum);
         System.out.printf("Average is %.1f%n",(float)(sum/a.length));
         System.out.println("Max score is "+max);
         System.out.println("Min score is "+min);

    }
}
