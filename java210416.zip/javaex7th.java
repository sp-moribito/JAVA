import java.util.Scanner;

public class javaex7th {
    public static void main(String[] args){
        //Q4-23
        // Scanner sc=new Scanner(System.in);
        // System.out.print("Number? ");
        // int num=sc.nextInt();

        // for(int i=1;i<=num;i++){
        //     for(int j=num-1;j>=i;j--){
        //         System.out.print(" ");
        //     }
        //     for(int k=1;k<=2*i-1;k++){
        //         System.out.print("*");
        //     }
        //     System.out.println();
        // }

        //Q4-24
        // Scanner sc=new Scanner(System.in);
        // System.out.print("Number? ");
        // int num=sc.nextInt();

        // for(int i=1;i<=num;i++){
        //     for(int j=num-1;j>=i;j--){
        //         System.out.print(" ");
        //     }
        //     for(int k=1;k<=2*i-1;k++){
        //         System.out.print(i%10);
        //     }
        //     System.out.println();
        // }

        //Q4-25
        // Scanner sc=new Scanner(System.in);
        // System.out.print("Number? ");
        // int num=sc.nextInt();
        // int count=0;

        // for(int i=2;i<num;i++){
        //     if(num%i==0){
        //         count++;
        //     }
        // }
        // if(count!=0){
        //     System.out.println(num+" is not prime number");
        // }
        // else{
        //     System.out.println(num+" is prime number");
        // }

        //Q4-26
        Scanner sc=new Scanner(System.in);
        System.out.print("How many? ");
        int num=sc.nextInt();
        int sum=0;
        int pn=0;
        
        for(int i=1;i<=num;i++){
            System.out.print("Number?(input 0 is terminated) ");
            pn=sc.nextInt();
            if(pn==0){
                if(i>=2){
                    System.out.println("Sum is "+sum);
                    System.out.println("Average is "+sum/i);
                    break;
                }
                else{
                    break;
                }
            }else if(i!=num){
                sum=sum+pn;
            }else if(i==num){
                sum=sum+pn;
                System.out.println("Sum is "+sum);
                System.out.println("Average is "+sum/i);
            }
        }
    }
}
