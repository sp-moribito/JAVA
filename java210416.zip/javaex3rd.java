import java.util.Scanner;

public class javaex3rd {
   public static void main(String[] args) {
       //Q4-8
    //    Scanner sc=new Scanner(System.in);
    //    System.out.print("How many is number : ");
    //    int num=sc.nextInt();

    //    for(int i=0;i<num;i++){
    //        if(i%2==0){
    //            System.out.print("*");
    //        }else if(i%2!=0){
    //            System.out.print("+");
    //        }
    //    }
    //    System.out.println("");

       //Q4-9
    //    Scanner sc=new Scanner(System.in);

    //    System.out.println("Positive number's numbers(?)");
    //    System.out.print("Input Positive number : ");
    //    int num=sc.nextInt();
    //    int count=0;

    //    while(num>0){
    //         count++;
    //         num=num/10;
    //    }
    //    System.out.println("Numbers is "+count);

       //Q4-10
       Scanner sc=new Scanner(System.in);
       System.out.print("Input Positive number : ");
       int num=sc.nextInt();
       int result=1;
       int i=1;

       while(num>=i){
           result=i*result;
           i++;
       }

       System.out.println("From 1 to "+num+"'s result is "+result);
   }
}
