import java.util.Scanner;

public class javaex4th {
    public static void main(String[] args){
        //Q4-11

        // Scanner sc=new Scanner(System.in);
        // System.out.print("Number? ");
        // int num=sc.nextInt();

        // for(int i=0;i<num;i++){
        //     System.out.print("*");
        // }
        // if(num>=1){
        //     System.out.println("");
        // }

        //Q4-12 : skip
        //Q4-13
        //Q4-14
        // Scanner sc=new Scanner(System.in);
        // System.out.print("Number? ");
        // int num=sc.nextInt();
        // int sum=0;

        // for(int i=1;i<=num;i++){
        //     sum=sum+i;
        // }
        // System.out.println("Sum from 1 to "+num+" is "+sum);

        //Q4-15
        // Scanner sc=new Scanner(System.in);
        // System.out.print("Number? ");
        // int num=sc.nextInt();
        // int sum=0;

        // for(int i=1;i<=num;i++){
        //     sum=sum+i;
        //     if(i!=num)
        //         System.out.print(i+"+");
        //     else
        //         System.out.print(i);
        // }
        // System.out.print("="+sum);

        //Q4-16
        Scanner sc=new Scanner(System.in);
        System.out.print("Start number? ");
        int num1=sc.nextInt();
        System.out.print("End number? ");
        int num2=sc.nextInt();
        System.out.print("By number? ");
        int num3=sc.nextInt();

        for (int i=num1;i<=num2;i=i+num3){
            System.out.println(i+" "+((i-100)*0.9));
        }
    }
}
