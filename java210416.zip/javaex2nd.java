import java.util.Scanner;

public class javaex2nd {
    public static void main(String[] args){
        //Q4-4
        // Scanner sc=new Scanner(System.in);
        // System.out.print("Number A : ");
        // int num1=sc.nextInt();
        // System.out.print("Number B : ");
        // int num2=sc.nextInt();
        
        // int a=0;
        // int b=0;
        // if(num1<num2){
        //     a=num1;
        //     b=num2;
        // }else if(num1>num2){
        //     a=num2;
        //     b=num1;
        // }

        // for(int i=a;i<b;i++){
        //     System.out.print(i+" ");
        // }

        //Q4-5
        // Scanner sc=new Scanner(System.in);
        // System.out.println("Countdown to zero");
        // int num;
        // do{
        //     System.out.print("Positive Number : ");
        //     num=sc.nextInt();   
        // }while(num<=0);

        // while (num>=0){
        //     System.out.println(num--);
        // }
        // System.out.println("x's value is "+num);

        //Q4-7
        Scanner sc=new Scanner(System.in);
        int num;
        
        do{
            System.out.print("*'s number is? ");
            num=sc.nextInt();
        }while(num<=0);

        for(int i=0;i<num;i++){
            System.out.print("*");
        }
    }
}
