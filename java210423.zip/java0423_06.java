import java.util.Scanner;
import java.util.Random;

public class java0423_06 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);

        //6-12
        // System.out.print("Array's length is... > ");
        // int[] arr=new int[sc.nextInt()];
        // int num;

        // Random rand=new Random();

        // for (int i=0;i<arr.length;i++){
        //     if(i==0){
        //         arr[i]=rand.nextInt(9)+1;
        //     }
        //     else{
        //         while(true){
        //             num=rand.nextInt(9)+1;
        //             int counter=0;
        //             for(int j=0;j<i;j++)
        //                 if(num==arr[j]){
        //                     counter++;
        //                 }
        //             if(counter==0){
        //                 arr[i]=num;
        //                 break;
        //             }
        //         }
        //     }
        //     System.out.println("a["+i+"] = "+arr[i]);
        // }

        //6-13

        // int[] arr={22,57,11,32,91,68,70};
        // int[] re_arr=new int[arr.length];
        // Random rand=new Random();

        // re_arr[rand.nextInt(arr.length)]=arr[0];
        // // System.out.println(re_arr[0]);
        // // System.out.println(re_arr[1]);

        // for(int i=1;i<arr.length;i++){
        //     while(true){
        //         int num=rand.nextInt(arr.length);
        //         if(re_arr[num]==0){
        //             re_arr[num]=arr[i];
        //             break;
        //         }
        //     }
        //     System.out.println(i+" "+re_arr[i]);
        // }

        //6-13 re

        Random rand = new Random();
        //Scanner sc = new Scanner(System.in);
        System.out.print("요소 수:");
        int n = sc.nextInt();
        int[] a = new int[n];

        for (int j = 0; j < n ; j++){
            System.out.print("a["+j+"] = ");
            a[j]= sc.nextInt();
        }

        System.out.println("요소를 섞었습니다.");

        for (int i = 0 ; i < n ; i++) {
            int x = rand.nextInt(n);
            int y = rand.nextInt(n);
            int t = a[x];
            a[x] = a[y];
            a[y] = t;
        }

        for (int j = 0; j < n ; j++){
            System.out.println("a["+j+"] = " + a[j]);
        }

    }
    
}
