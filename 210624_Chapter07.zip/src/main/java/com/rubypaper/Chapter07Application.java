package com.rubypaper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter07Application {

	public static void main(String[] args) {
		SpringApplication.run(Chapter07Application.class, args);
	}

}
