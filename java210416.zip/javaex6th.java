import java.util.Scanner;

public class javaex6th {
    public static void main(String[] args){
        //Q4-22
        Scanner sc=new Scanner(System.in);
        System.out.print("Number? ");
        int num=sc.nextInt();

        for(int i=1;i<=num;i++){
            for(int j=1;j<=i;j++)
                System.out.print("*");
            System.out.println();
        }

        System.out.println();

        for(int i=num;i>=1;i--){
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }
            System.out.println();
        }

        System.out.println();

        for(int i=0;i<num;i++){
            for(int j=0;j<i;j++){
                System.out.print(" ");
            }
            for(int k=0;k<num-i;k++){
                System.out.print("*");
            }
            System.out.println();
        }
        // 1(0) : 0 * 5
        // 2(1) : 1 * 4
        // 3(2) : 2 * 3
        // 4(3) : 3 * 2
        // 5(4) : 4 * 1
    }
}
