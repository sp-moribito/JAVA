import java.util.Scanner;
import java.util.Random;

public class java0423_05 {
    public static void main(String[] args){

        Scanner sc=new Scanner(System.in);

        //6-8
        // System.out.print("");
        // int[] arr=new int[sc.nextInt()];

        // for (int i=0;i<arr.length;i++){
        //     arr[i]=sc.nextInt();
        // }

        // System.out.println("What find is number?");
        // int num=sc.nextInt();

        // for(int i=0;i<arr.length;i++){
        //     if(arr[i].equals(num)){

        //     }
        // }

        //6-10
        // System.out.print("Array's length is... > ");
        // int[] arr=new int[sc.nextInt()];

        // Random rand=new Random();

        // for (int i=0;i<arr.length;i++){
        //     arr[i]=rand.nextInt(9)+1;
        //     System.out.println(i+" "+arr[i]);
        // }
        //6-11
        // System.out.print("Array's length is... > ");
        // int[] arr=new int[sc.nextInt()];
        // int num;

        // Random rand=new Random();

        // for (int i=0;i<arr.length;i++){
        //     if(i==0){
        //         arr[i]=rand.nextInt(9)+1;
        //     }
        //     else{
        //         while(true){
        //             num=rand.nextInt(9)+1;
        //             if(num!=arr[i-1]){
        //                 arr[i]=num;
        //                 break;
        //             }
        //         }
        //     }
        //     System.out.println(i+" "+arr[i]);
        // }

        


    }
}
