import java.util.Scanner;
import java.util.Random;

public class javaex1st{
    public static void main(String[] args){
        //Q4-1
        // while(true){
        //     Scanner sc=new Scanner(System.in);
        //     System.out.print("Input : ");
        //     int num=sc.nextInt();

        //     if(num>0){
        //         System.out.println("This value is positive number.");
        //     }else if(num<0){
        //         System.out.println("This value is negative number.");
        //     }else{
        //         System.out.println("This value is zero.");
        //     }
        //     System.out.print("Again? 1-yes/0-no:");
        //     int num2=sc.nextInt();
            
        //     if(num2==0)
        //         break;
        // }

        //Q4-1 : Best Answer
        // int num2;
        // do{
        //     Scanner sc=new Scanner(System.in);
        //     System.out.print("Input : ");
        //     int num=sc.nextInt();

        //     if(num>0){
        //         System.out.println("This value is positive number.");
        //     }else if(num<0){
        //         System.out.println("This value is negative number.");
        //     }else{
        //         System.out.println("This value is zero.");
        //     }
        //     System.out.print("Again? 1-yes/0-no:");
        //     num2=sc.nextInt();
        // }while(num2==1);

        //Q4-2
        // int num;
        // do{
        //     Scanner sc=new Scanner(System.in);
        //     System.out.print("Input : ");
        //     num=sc.nextInt();
        // }while(num<100 || num>999);

        // System.out.println("value is "+num);

        //Q4-3
        Random rand=new Random();
        Scanner sc=new Scanner(System.in);
        int num=rand.nextInt(90)+10;
        int ans;
        
        System.out.println("Game Start!");
        System.out.println("Number between 10 to 99");
        
        do{
            System.out.print("Number is ? ");
            ans=sc.nextInt();
            if(ans>num){
                System.out.println("Big");
            }else if(ans<num){
                System.out.println("Small");
            }
        }while(ans!=num);
        System.out.println("Yes!!!");

    }
}