import java.util.Scanner;

public class java0423_03 {
    public static void main(String[] args){
        //5-6;
        // Scanner sc=new Scanner(System.in);
        // System.out.print("Input number 1 >");
        // int num1=sc.nextInt();
        // System.out.print("Input number 2 >");
        // int num2=sc.nextInt();
        // System.out.print("Input number 3 >");
        // int num3=sc.nextInt();

        // System.out.println("Sum is "+(num1+num2+num3));
        // System.out.println("Average is "+(num1+num2+num3)/3);

        //5-7
        // int a;
        // a=(int)10.0;

        // System.out.println(a);

        //5-8
        System.out.println("float      int");
        System.out.println("==============");

        float x=0.0F;
        for (int i=0;i<1000;i++,x+=0.001F){
            //System.out.println(x+" "+(float)i/1000);
            System.out.printf("%10.7f   %10.7f%n",x,(float)i/1000);
        }

       
    }
}
