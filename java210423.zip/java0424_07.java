import java.util.Scanner;
import java.util.Random;

public class java0424_07 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);

        //6-14
        // int[] arr=new int[5];
        // int[] re_arr=new int[5];

        // for (int i=0;i<arr.length;i++){
        //     System.out.println("a["+i+"] ="+arr[i]);
        // }
        // System.out.println("");
        // for (int i=0;i<arr.length;i++){
        //     re_arr[arr.length-i]=arr[i];
        //     System.out.println("b["+i+"] ="+re_arr[i]);
        // }

        //6-15
        String[] months={"January","Feburary","March","April","May","June","July","August","September","October","November","December"};

        System.out.println("== Input Month to English ==");
        System.out.println("First charcter is Captital");
        Random rand=new Random();
        int month=rand.nextInt(12)+1;

        while(true){
            System.out.print(month+" month : ");
            String str=sc.nextLine();

            if(str.equals(months[month-1])==true){
                System.out.print("Correct Answer! ");
                System.out.print("Again? 1...Yes/0...No :");
                int num=sc.nextInt();
                if(num==0)
                    break;
                else{
                    month=rand.nextInt(12)+1;
                    str=sc.nextLine();
                }
            }else{
                System.out.println("Wrong Answer!");
            }
        }

    }
}
